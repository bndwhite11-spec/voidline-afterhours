'use strict';
// Actual illustration runtime, controlled DOM/WAAPI and Python's XML parser.
// This does not establish browser rendering, timing, touch or accessibility acceptance.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const source=require('esbuild').buildSync({entryPoints:[path.join(__dirname,'../src/art/client.mjs')],bundle:true,write:false,format:'iife',globalName:'testArt'}).outputFiles[0].text;
const tests=[],test=(name,run)=>tests.push([name,run]);
function held(){let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return{promise,resolve,reject};}
function fixture(options={}){
 const calls=[],animations=[],observers=[],mutations=[],events=new Map(),windowEvents=new Map(),mediaEvents=new Map(),flags={appReduced:false,osReduced:false},classes=new Set();
 const parseCode=`import json,sys,xml.etree.ElementTree as ET\ndef node(e):\n return {'tag':e.tag.rsplit('}',1)[-1],'attrs':{('xlink:'+k.rsplit('}',1)[-1] if k.startswith('{http://www.w3.org/1999/xlink}') else k):v for k,v in e.attrib.items()},'children':[node(c) for c in e]}\ntry: print(json.dumps(node(ET.fromstring(sys.stdin.read()))))\nexcept Exception: print(json.dumps({'tag':'parsererror','attrs':{},'children':[]}))`;
 const match=(node,selector)=>{
  if(selector==='*')return true;const attr=/\[([^=\]]+)="([^"]*)"\]/.exec(selector);if(attr&&node.getAttribute(attr[1])!==attr[2])return false;
  const cls=/\.([\w-]+)/.exec(selector);if(cls&&!node.classList.contains(cls[1]))return false;
  const tag=/^([A-Za-z][\w-]*)/.exec(selector);return !tag||node.localName===tag[1];
 };
 class Element{
  constructor(tag='div',attrs={},children=[]){this.localName=tag;this.attrs=new Map(Object.entries(attrs));this.children=[];this.dataset={};this.isConnected=true;for(const[k,v]of this.attrs)this.syncData(k,v);this.classList={add:(...v)=>{const c=new Set((this.getAttribute('class')||'').split(/\s+/).filter(Boolean));for(const x of v)c.add(x);this.attrs.set('class',[...c].join(' '));},remove:(...v)=>{const c=new Set((this.getAttribute('class')||'').split(/\s+/).filter(Boolean));for(const x of v)c.delete(x);this.attrs.set('class',[...c].join(' '));},contains:v=>(this.getAttribute('class')||'').split(/\s+/).includes(v)};this.replaceChildren(...children);}
  get attributes(){return [...this.attrs].map(([name,value])=>({name,value}));}
  get firstChild(){return this.children[0]||null;}
  get firstElementChild(){return this.children[0]||null;}
  syncData(name,value){if(name.startsWith('data-'))this.dataset[name.slice(5).replace(/-([a-z])/g,(_m,c)=>c.toUpperCase())]=value;}
  getAttribute(name){return this.attrs.has(name)?this.attrs.get(name):null;}
  setAttribute(name,value){this.attrs.set(name,String(value));this.syncData(name,String(value));}
  removeAttribute(name){this.attrs.delete(name);}
  matches(selector){return match(this,selector);}
  querySelectorAll(selector){const result=[];for(const child of this.children){if(match(child,selector))result.push(child);result.push(...child.querySelectorAll(selector));}return result;}
  querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
  contains(node){return node===this||this.children.some(child=>child.contains(node));}
  disconnect(){this.isConnected=false;for(const child of this.children)child.disconnect();}
  replaceChildren(...children){for(const old of this.children||[])old.disconnect();this.children=children;for(const child of children){child.parent=this;child.isConnected=this.isConnected;}}
  clone(){const node=new Element(this.localName,Object.fromEntries(this.attrs),this.children.map(child=>child.clone()));node.dataset={...this.dataset};return node;}
  animate(frames,settings){const complete=held(),animation={target:this,frames,settings,finished:complete.promise,cancelled:false,currentTime:0,play(){this.paused=false;},pause(){this.paused=true;},cancel(){if(this.cancelled)return;this.cancelled=true;complete.reject(new Error('Animation cancelled'));},finish(){complete.resolve();}};animations.push(animation);return animation;}
 }
 function fromJSON(raw){return new Element(raw.tag,raw.attrs,(raw.children||[]).map(fromJSON));}
 const catalog={};for(const id of ['badge-a','gift-b'])catalog[id]={id,name:id,type:id==='gift-b'?'gift':'badge',series:'Controlled fixture',material:'Steel',alt:'A controlled editable illustration.',mini:'<path d="M2 2h20v20H2Z" fill="#ddd"/>',cardURL:'/art/v4/'+id+'-card.0123456789ab.svg',detailURL:'/art/v4/'+id+'-detail.abcdef012345.svg',silhouetteURL:'/art/v4/'+id+'-silhouette.0123456789ab.svg',motion:{duration:1300,layers:[{name:'hinge',origin:[40,60],frames:[{at:0},{at:.4,rotate:-25,y:-2},{at:1,rotate:-20,opacity:.8}]}]}};
 const valid=id=>`<svg xmlns="http://www.w3.org/2000/svg" data-vc-object="${id}" width="256" height="256" aria-labelledby="fixture-title"><title id="fixture-title">A fixture</title><defs><linearGradient id="paint"><stop offset="0" stop-color="#fff"/></linearGradient><clipPath id="clip"><rect width="20" height="20"/></clipPath></defs><g data-part="hinge" opacity=".35" transform="matrix(1 0 0 1 9 3)"><path id="shape" fill="url(#paint)" clip-path="url(#clip)" d="M1 1h18v18H1Z"/></g></svg>`;
 const document={hidden:false,documentElement:{classList:{contains:v=>classes.has(v)}},body:new Element('body'),addEventListener:(name,fn)=>events.set(name,fn),importNode:node=>node.clone()};
 const media={get matches(){return flags.osReduced;},addEventListener:(name,fn)=>mediaEvents.set(name,fn)};
 const context={document,console,TextEncoder,TextDecoder,Promise,Map,Set,WeakMap,AbortController,crypto:options.crypto||require('node:crypto').webcrypto,atob:value=>Buffer.from(value,'base64').toString('binary'),window:{VoidHome:{request(){throw Error('Account API must not be called');}},VoidTheme:{state:()=>({effectiveReducedMotion:flags.appReduced})},matchMedia:()=>media,addEventListener:(name,fn)=>windowEvents.set(name,fn)},fetch:async(url,request)=>{calls.push({url,request});if(api.fetchReply)return api.fetchReply(url,request);return{ok:true,text:async()=>valid(url.includes('gift-b')?'gift-b':'badge-a')};},DOMParser:class{parseFromString(text,type){assert.equal(type,'image/svg+xml');const result=spawnSync('python3',['-c',parseCode],{input:text,encoding:'utf8',maxBuffer:1024*1024});if(result.status)throw Error(result.stderr);const node=fromJSON(JSON.parse(result.stdout));return{documentElement:node,querySelector:selector=>node.matches(selector)?node:node.querySelector(selector)};}},IntersectionObserver:class{constructor(fn,config){this.fn=fn;this.config=config;this.disconnected=false;observers.push(this);}observe(target){this.target=target;}disconnect(){this.disconnected=true;}},MutationObserver:class{constructor(fn){this.fn=fn;this.disconnected=false;mutations.push(this);}observe(target,config){this.target=target;this.config=config;}disconnect(){this.disconnected=true;}},__catalog:catalog};
 vm.createContext(context);vm.runInContext(source+'\ntestArt.installArt(__catalog,4);',context);
 const api={art:context.window.VoidCollectibleArt,catalog,valid,Element,calls,animations,observers,mutations,events,windowEvents,mediaEvents,flags,classes,document,fetchReply:null,web(id='gift-b'){const bytes=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLbtAAAAABJRU5ErkJggg==','base64'),uri='data:image/png;base64,'+bytes.toString('base64'),digest=require('node:crypto').createHash('sha256').update(bytes).digest('hex');catalog[id].sourceArt={mime:'image/png',bytes:bytes.length,sha256:digest,mini:{path:'/art/sources/controlled-mini.'+digest.slice(0,12)+'.png'}};const svg=`<svg xmlns="http://www.w3.org/2000/svg" data-vc-object="${id}"><defs><image id="source-image" href="${uri}" x="0" y="0" width="256" height="256"/></defs><g data-part="hinge"><use href="#source-image"/></g></svg>`;catalog[id].detailBytes=Buffer.byteLength(svg);return{bytes,uri,svg};},host(id='badge-a',outer=false){const art=new Element('span',{'class':'vc-art va-asset','data-vc-object':id}),container=outer?new Element('div',{},[art]):art;document.body.children.push(container);return{container,art};},tick:async()=>{for(let i=0;i<8;i++)await Promise.resolve();}};
 return api;
}

test('static rendering and preview issue no account writes; only known fingerprinted illustration GETs omit credentials',async()=>{
 const f=fixture(),{container}=f.host();assert.match(f.art.render('badge-a',true),/viewBox="0 0 24 24"/);assert.match(f.art.render('badge-a'),/loading="lazy"/);assert.match(f.art.detail('badge-a'),/loading="eager"/);assert.equal(f.calls.length,0);assert.equal((await f.art.preview(container,'not-a-design')).played,false);assert.equal(f.calls.length,0);const played=await f.art.preview(container,'badge-a');assert.equal(played.played,true);assert.equal(f.calls.length,1);assert.match(f.calls[0].url,/^\/art\/v4\/[a-z-]+-detail\.[a-f0-9]{12}\.svg$/);const {signal,...policy}=f.calls[0].request;assert.deepEqual({...policy},{credentials:'omit',cache:'force-cache',redirect:'error'});assert.equal(signal.aborted,false);assert.ok(!f.calls.some(call=>call.url.startsWith('/api/')));f.art.stopAll();
});
test('web artwork mounts only the exact hashed raster and rewrites local image uses independently',async()=>{
 const f=fixture(),web=f.web(),a=f.host('gift-b'),b=f.host('gift-b');f.fetchReply=async()=>({ok:true,text:async()=>web.svg});
 const miniature=f.art.render('gift-b',true);assert.match(miniature,/^<img /);assert(miniature.includes('src="'+f.catalog['gift-b'].sourceArt.mini.path+'"'));assert(!miniature.includes('base64'));assert.equal(f.calls.length,0,'miniature uses a fixed static image URL without fetching detail data');
 const first=await f.art.mount(a.container,'gift-b'),second=await f.art.mount(b.container,'gift-b');assert(first&&second);const idA=first.querySelector('image').getAttribute('id'),idB=second.querySelector('image').getAttribute('id');assert.notEqual(idA,idB);assert.equal(first.querySelector('image').getAttribute('href'),web.uri);assert.equal(first.querySelector('use').getAttribute('href'),'#'+idA);assert.equal(second.querySelector('use').getAttribute('href'),'#'+idB);assert.equal(f.calls.length,1);assert(!f.calls.some(call=>call.url.startsWith('/api/')));
});
test('web scenes reject remote, file-local, SVG-data, changed-raster and foreign local-use references',async()=>{
 for(const mode of ['remote','local','svg','changed','mime','hash','second-image','foreign-use','xlink']){const f=fixture(),web=f.web(),{container}=f.host('gift-b');let svg=web.svg;if(mode==='remote')svg=svg.replace(web.uri,'https://example.com/source.png');if(mode==='local')svg=svg.replace(web.uri,'/art/sources/source.0123456789ab.png');if(mode==='svg')svg=svg.replace(web.uri,'data:image/svg+xml;base64,PHN2Zy8+');if(mode==='changed')svg=svg.replace(web.uri,web.uri.slice(0,-4)+'AAAA');if(mode==='mime')f.catalog['gift-b'].sourceArt.mime='image/webp';if(mode==='hash')f.catalog['gift-b'].sourceArt.sha256='0'.repeat(64);if(mode==='second-image')svg=svg.replace('</defs>','<image href="'+web.uri+'"/></defs>');if(mode==='foreign-use')svg=svg.replace('href="#source-image"','href="#not-the-image"');if(mode==='xlink')svg=svg.replace('href="'+web.uri+'"','xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="'+web.uri+'"');f.catalog['gift-b'].detailBytes=Buffer.byteLength(svg);f.fetchReply=async()=>({ok:true,text:async()=>svg});assert.equal(await f.art.mount(container,'gift-b'),null,mode);assert.equal(f.animations.length,0,mode);}
});
test('cancellation during asynchronous raster verification cannot install or animate an older scene',async()=>{
 const wait=held(),entered=held();const f=fixture({crypto:{subtle:{digest:async()=>{entered.resolve();return wait.promise;}}}}),web=f.web(),{container}=f.host('gift-b');f.fetchReply=async()=>({ok:true,text:async()=>web.svg});const task=f.art.preview(container,'gift-b');let timer;try{await Promise.race([entered.promise,new Promise((_yes,no)=>{timer=setTimeout(()=>no(Error('Raster verification did not start')),1000);})]);}finally{clearTimeout(timer);}f.art.stopAll();wait.resolve(await require('node:crypto').webcrypto.subtle.digest('SHA-256',web.bytes));assert.equal((await task).played,false);assert.equal(container.querySelector('svg'),null);assert.equal(f.animations.length,0);
});
test('mounted IDs and local references are independently namespaced for repeated scenes',async()=>{
 const f=fixture(),a=f.host(),b=f.host();const first=await f.art.mount(a.container,'badge-a'),second=await f.art.mount(b.container,'badge-a');assert(first&&second);const idA=first.querySelector('linearGradient').getAttribute('id'),idB=second.querySelector('linearGradient').getAttribute('id');assert.notEqual(idA,idB);assert.equal(first.querySelector('path').getAttribute('fill'),'url(#'+idA+')');assert.equal(second.querySelector('path').getAttribute('fill'),'url(#'+idB+')');assert.equal(f.calls.length,1);assert.equal(first.getAttribute('aria-hidden'),'true');
});
test('malformed, wrong-object, script, external reference, event-handler and duplicate-ID scenes never mount',async()=>{
 const samples=['<svg broken','<div/>','<svg xmlns="http://www.w3.org/2000/svg" data-vc-object="gift-b"/>','<svg data-vc-object="badge-a"><script>alert(1)</script></svg>','<svg data-vc-object="badge-a"><image href="https://example.com/pixel"/></svg>','<svg data-vc-object="badge-a"><path onload="alert(1)"/></svg>','<svg data-vc-object="badge-a"><path fill="url(https://example.com/fill.svg#paint)"/></svg>','<svg data-vc-object="badge-a"><path id="same"/><path id="same"/></svg>','<svg data-vc-object="badge-a"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#outside"/></svg>'];
 for(const text of samples){const f=fixture(),{container,art}=f.host();f.fetchReply=async()=>({ok:true,text:async()=>text});assert.equal(await f.art.mount(container,'badge-a'),null,text);assert.equal(art.querySelector('svg'),null,text);assert.equal(f.animations.length,0);}
 const oversized=fixture(),host=oversized.host();oversized.fetchReply=async()=>({ok:true,text:async()=>oversized.valid('badge-a')+' '.repeat(70001)});assert.equal(await oversized.art.mount(host.container,'badge-a'),null);
});
test('failed and redirected asset responses keep the static image and permit a later valid retry',async()=>{
 const f=fixture(),{container}=f.host();f.fetchReply=async()=>{throw Error('Redirect rejected');};assert.equal(await f.art.mount(container,'badge-a'),null);f.fetchReply=async()=>({ok:false,text:async()=>''});assert.equal(await f.art.mount(container,'badge-a'),null);f.fetchReply=null;assert(await f.art.mount(container,'badge-a'));assert.equal(f.calls.length,3);
});
test('stopAll invalidates overlapping pending mounts even when an earlier request has already failed',async()=>{
 const f=fixture(),container=new f.Element('div'),first=held(),second=held();f.document.body.children.push(container);f.fetchReply=url=>url.includes('gift-b')?second.promise:first.promise;const a=f.art.mount(container,'badge-a'),b=f.art.mount(container,'gift-b');assert.equal(f.calls.length,2);first.resolve({ok:false,text:async()=>''});assert.equal(await a,null);assert.equal(container.children.length,0);f.art.stopAll();second.resolve({ok:true,text:async()=>f.valid('gift-b')});assert.equal(await b,null);assert.equal(container.children.length,0);assert.equal(f.animations.length,0);
});
test('pending scenes cannot insert or start after abort, disconnection or stopAll',async()=>{
 for(const reason of ['abort','disconnect','stop']){const f=fixture(),{container,art}=f.host(),waiting=held(),controller=new AbortController();f.fetchReply=()=>waiting.promise;const task=f.art.preview(container,'badge-a',{signal:controller.signal});if(reason==='abort')controller.abort();if(reason==='disconnect')container.disconnect();if(reason==='stop')f.art.stopAll();waiting.resolve({ok:true,text:async()=>f.valid('badge-a')});const result=await task;assert.equal(result.played,false,reason);assert.equal(art.querySelector('svg'),null,reason);assert.equal(f.animations.length,0,reason);}
});
test('a connected stage replacement, same-host child replacement or retargeting cannot receive older pending artwork',async()=>{
 for(const reason of ['nested','same-host','retarget']){const f=fixture(),{container,art}=f.host('badge-a',reason==='nested'),waiting=held();f.fetchReply=()=>waiting.promise;const task=f.art.preview(container,'badge-a');if(reason==='nested')container.replaceChildren(new f.Element('span',{'class':'va-asset','data-vc-object':'gift-b'}));if(reason==='same-host')container.replaceChildren(new f.Element('img',{'src':'newer-still.svg'}));if(reason==='retarget')art.setAttribute('data-vc-object','gift-b');waiting.resolve({ok:true,text:async()=>f.valid('badge-a')});const result=await task;assert.equal(result.played,false,reason);assert.equal(art.querySelector('svg'),null,reason);assert.equal(f.animations.length,0,reason);}
});
test('disconnection after insertion but before the awaiting preview resumes cannot start animations',async()=>{
 const f=fixture(),{container,art}=f.host(),replace=art.replaceChildren.bind(art);art.replaceChildren=(...nodes)=>{replace(...nodes);queueMicrotask(()=>container.disconnect());};const result=await f.art.preview(container,'badge-a');assert.equal(result.played,false);assert.equal(f.animations.length,0);
});
test('part choreography preserves base transforms and opacity, holds its final pose and never loops',async()=>{
 const f=fixture(),{container}=f.host();const svg=await f.art.mount(container,'badge-a'),part=svg.querySelector('[data-part="hinge"]');part.transform={baseVal:{consolidate:()=>({matrix:{a:1,b:0,c:0,d:1,e:9,f:3}})}};const result=await f.art.preview(container,'badge-a');assert.equal(result.played,true);assert.equal(f.animations.length,1);const animation=f.animations[0];assert.equal(animation.target,part);assert.equal(animation.settings.duration,1300);assert.equal(animation.settings.iterations,1);assert.equal(animation.settings.fill,'forwards');assert.equal(animation.settings.easing,'linear');assert.equal(animation.frames[0].opacity,.35);assert.match(animation.frames[0].transform,/matrix\(1,0,0,1,9,3\)$/);assert.match(animation.frames[1].transform,/rotate\(-25deg\)/);assert.equal(animation.frames.at(-1).opacity,.8);animation.finish();await result.finished;assert.equal(animation.cancelled,true);assert.equal(part.getAttribute('opacity'),'0.8');assert.match(part.getAttribute('transform'),/rotate\(-20\)/);assert.equal(f.animations.length,1);assert.equal(container.classList.contains('va-playing'),false);assert(f.observers[0].disconnected&&f.mutations[0].disconnected);f.art.stop(container);assert.equal(part.getAttribute('opacity'),'.35');assert.equal(part.getAttribute('transform'),'matrix(1 0 0 1 9 3)');
});
test('OS/app reduced motion and hidden documents do not start previews or fetch detailed scenes',async()=>{
 for(const reason of ['os','app','class','hidden']){const f=fixture(),{container}=f.host();if(reason==='os')f.flags.osReduced=true;if(reason==='app')f.flags.appReduced=true;if(reason==='class')f.classes.add('vh-reduced-motion');if(reason==='hidden')f.document.hidden=true;assert.equal((await f.art.preview(container,'badge-a')).played,false,reason);assert.equal(f.animations.length,0,reason);assert.equal(f.calls.length,0,reason);}
});
test('motion cancels on preference changes, visibility, offscreen, scene replacement, disconnection and page exit',async()=>{
 for(const reason of ['os','app','hidden','offscreen','replacement','disconnect','pagehide']){const f=fixture(),{container}=f.host(),played=await f.art.preview(container,'badge-a');assert.equal(played.played,true);const animation=f.animations[0];if(reason==='os'){f.flags.osReduced=true;f.mediaEvents.get('change')({matches:true});}if(reason==='app'){f.flags.appReduced=true;f.windowEvents.get('voidline:theme')();}if(reason==='hidden'){f.document.hidden=true;f.events.get('visibilitychange')();}if(reason==='offscreen')f.observers[0].fn([{isIntersecting:false}]);if(reason==='replacement'){container.replaceChildren(new f.Element('span'));f.mutations[0].fn();}if(reason==='disconnect'){container.disconnect();f.mutations[0].fn();}if(reason==='pagehide')f.windowEvents.get('pagehide')();assert.equal(animation.cancelled,true,reason);assert.equal(container.classList.contains('va-playing'),false,reason);assert.equal(f.observers[0].disconnected,true,reason);assert.equal(f.mutations[0].disconnected,true,reason);await played.finished;}
});
test('stale preview stop, abort and queued observer callbacks cannot cancel a newer preview on the same stage',async()=>{
 for(const reason of ['returned-stop','old-abort','old-intersection','old-replacement-observer']){const f=fixture(),{container}=f.host(),controller=new AbortController(),first=await f.art.preview(container,'badge-a',{signal:controller.signal}),oldIntersection=f.observers[0],oldMutation=f.mutations[0];if(reason==='old-replacement-observer'){container.setAttribute('data-vc-object','gift-b');container.replaceChildren(new f.Element('img',{'src':'new-gift-still.svg'}));}const second=await f.art.preview(container,reason==='old-replacement-observer'?'gift-b':'badge-a');assert.equal(second.played,true,reason);assert.equal(f.animations[0].cancelled,true,reason);assert.equal(f.animations[1].cancelled,false,reason);if(reason==='returned-stop')first.stop();if(reason==='old-abort')controller.abort();if(reason==='old-intersection')oldIntersection.fn([{isIntersecting:false}]);if(reason==='old-replacement-observer')oldMutation.fn();assert.equal(f.animations[1].cancelled,false,reason);second.stop();assert.equal(f.animations[1].cancelled,true,reason);}
});
test('a declined preview has no cancellation authority over a later successful preview',async()=>{
 const f=fixture(),{container}=f.host(),declined=await f.art.preview(container,'unknown-id');assert.equal(declined.played,false);const current=await f.art.preview(container,'badge-a');assert.equal(current.played,true);declined.stop();assert.equal(f.animations[0].cancelled,false);current.stop();assert.equal(f.animations[0].cancelled,true);
});
test('a second foreground host stops the first playback and abort releases the active scene',async()=>{
 const f=fixture(),a=f.host(),b=f.host('gift-b'),controller=new AbortController(),first=await f.art.preview(a.container,'badge-a'),second=await f.art.preview(b.container,'gift-b',{signal:controller.signal});assert.equal(first.played,true);assert.equal(second.played,true);assert.equal(f.animations[0].cancelled,true);assert.equal(await first.finished,'stopped');assert.equal(f.animations[1].cancelled,false);controller.abort();assert.equal(f.animations[1].cancelled,true);await second.finished;assert(a.art.querySelector('svg'));assert(b.art.querySelector('svg'));assert.ok(!f.calls.some(call=>call.url.startsWith('/api/')));
});
test('closing a stage releases pending fetches; a second consumer keeps the shared request alive',async()=>{
 const f=fixture(),a=f.host(),b=f.host(),network=held();f.fetchReply=()=>network.promise;
 const first=f.art.prepare(a.container,'badge-a'),second=f.art.prepare(b.container,'badge-a');
 assert.equal(f.calls.length,1);f.art.stop(a.container);assert.equal(f.calls[0].request.signal.aborted,false);
 f.art.stop(b.container);assert.equal(f.calls[0].request.signal.aborted,true);
 network.resolve({ok:true,text:async()=>f.valid('badge-a')});assert.equal((await first).reason,'cancelled');assert.equal((await second).reason,'cancelled');
 f.fetchReply=null;assert((await f.art.prepare(a.container,'badge-a')).svg);assert.equal(f.calls.length,2);
});
test('manual frame inspection pauses all tracks until another foreground selection',async()=>{
 const f=fixture(),first=f.host(),other=f.host(),a=await f.art.preview(first.container,'badge-a',{pausedAt:0.5});
 assert.equal(first.container.dataset.vaState,'paused');assert.equal(f.animations[0].currentTime,650);assert.equal(f.animations[0].paused,true);
 a.seek(.75);assert.equal(f.animations[0].currentTime,975);a.resume();assert.equal(f.animations[0].paused,false);a.pause();
 const b=await f.art.preview(other.container,'badge-a');assert(!f.animations[1].cancelled);a.stop();assert.equal(await a.finished,'stopped');assert(!f.animations[1].cancelled);b.stop();
});
test('invalid asset cache is evicted, reasons distinguish validation and missing file, poster survives both',async()=>{
 const f=fixture(),{container}=f.host();const poster=new f.Element('img');container.replaceChildren(poster);
 f.fetchReply=()=>({ok:false});assert.equal((await f.art.prepare(container,'badge-a')).reason,'asset-unavailable');
 f.fetchReply=()=>({ok:true,text:async()=>'<svg></svg>'});assert.equal((await f.art.preview(container,'badge-a')).reason,'validation-rejected');
 assert.equal(container.firstChild,poster);f.fetchReply=null;assert((await f.art.prepare(container,'badge-a')).svg);assert.equal(f.calls.length,3);
});
test('unknown IDs retain authorized names and make no asset request',async()=>{
 const f=fixture(),m=f.art.render('missing-id',false,'Moon <1>');assert.match(m,/Moon &lt;1&gt; · Artwork unavailable/);assert(!m.includes('<img'));assert.match(f.art.render('missing-id',true),/missing-id/);assert.equal(f.calls.length,0);
});
test('the complete immutable detail digest rejects a same-length change before mounting',async()=>{
 const f=fixture(),a=f.catalog['badge-a'],h=f.host(),body=f.valid('badge-a');
 a.detailBytes=Buffer.byteLength(body);a.detailSHA256=require('node:crypto').createHash('sha256').update(body).digest('hex');
 f.fetchReply=()=>({ok:true,text:async()=>body.replace('hinge','hingf')});
 assert.equal((await f.art.prepare(h.container,a.id)).reason,'validation-rejected');
 f.fetchReply=()=>({ok:true,text:async()=>body});assert((await f.art.prepare(h.container,a.id)).svg);
});
test('an idle least-recently-used detail is fetched again after eight other validated details',async()=>{
 const f=fixture(),base=f.catalog['badge-a'];for(let i=0;i<10;i++){const id='model-'+i;f.catalog[id]={...base,id,detailURL:'/art/v4/'+id+'-detail.abcdef012345.svg'};}
 f.fetchReply=url=>({ok:true,text:async()=>f.valid(/(model-\d+)/.exec(url)[1])});
 for(let i=0;i<10;i++){const id='model-'+i;assert(await f.art.mount(f.host(id).container,id));}
 assert.equal(f.calls.length,10);assert(await f.art.mount(f.host('model-9').container,'model-9'));assert.equal(f.calls.length,10);
 assert(await f.art.mount(f.host('model-0').container,'model-0'));assert.equal(f.calls.length,11);
});
(async()=>{let failed=0;for(const[name,run]of tests){try{await run();console.log('PASS '+name);}catch(error){failed++;console.error('FAIL '+name+'\n'+error.stack);}}console.log(`${tests.length-failed}/${tests.length} illustration runtime checks passed. Actual module with controlled DOM/WAAPI, real XML parsing and mocked static transport; not browser animation/device acceptance.`);process.exitCode=failed?1:0;})();
