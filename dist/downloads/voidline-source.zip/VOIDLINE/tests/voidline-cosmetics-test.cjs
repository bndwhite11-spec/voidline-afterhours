'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const {webcrypto}=require('node:crypto');
const artSource=fs.readFileSync(path.join(__dirname,'../dist/collectible-art.js'),'utf8');
const css=fs.readFileSync(path.join(__dirname,'../dist/cosmetics.css'),'utf8');
const source=fs.readFileSync(path.join(__dirname,'../dist/cosmetics.js'),'utf8');
const tests=[],test=(name,fn)=>tests.push([name,fn]);
const held=()=>{let resolve,reject;return {promise:new Promise((a,b)=>{resolve=a;reject=b;}),get resolve(){return resolve;},get reject(){return reject;}};};
function fixture(options={}){
 const nodes=new Map(),listeners=new Map(),windowListeners=new Map(),calls=[],announcements=[],replies=new Map(),timers=new Map(),artCalls=[],artStops=[],artMounts=[],dialogIds=new Set(),pageIds=new Set();let renders=0,extension,timerSerial=0,collectionPanel=null,main=null,dialog=null;
 const catalog=options.catalog||[{id:'angel',type:'badge',name:'404 Angel',finish:'Chrome',description:'A free cosmetic.',acquisition:'Free to collect.',price:0},{id:'gift-rose',type:'gift',name:'Chrome Rose',finish:'Rose chrome',description:'A free gift.',acquisition:'Free to collect.',price:0}];
 const state={account:{id:'account-a'},generation:0,dialogGeneration:0,secureRoomId:null,view:'chats'};
 const media={matches:!!options.osReduced},liveArt=new Set();
 function node(id='',owner=null){const classes=new Set(),attributes=new Map();return {id,owner,isConnected:true,innerHTML:'',textContent:'',disabled:false,value:'',dataset:{},scrollTop:0,classList:{add:v=>classes.add(v),remove:v=>classes.delete(v),contains:v=>classes.has(v)},insertAdjacentHTML(_p,text){this.innerHTML+=text;},querySelector(selector){if(selector.startsWith('#')){const found=nodes.get(selector.slice(1));return found?.owner===this?found:null;}if(selector.startsWith('[data-vc-action="inspect"]')){const result=node('inspect-return-target',this);result.dataset.item=selector.match(/data-item="([^"]+)"/)?.[1];return result;}return null;},closest(selector){if(selector==='dialog')return owner===dialog?dialog:null;if(selector==='#home-main')return owner===main?main:null;return null;},hasAttribute(name){return attributes.has(name)||name==='data-vc-search'&&this.dataset.vcSearch!==undefined;},setAttribute(name,value){attributes.set(name,String(value));},focus(){document.activeElement=this;}};}
 function clearIds(ids){for(const id of ids){const n=nodes.get(id);if(n?.nodeType)n.remove();else if(n)n.isConnected=false;nodes.delete(id);}ids.clear();}
 function installHTML(owner,html,ids){clearIds(ids);owner.innerHTML=html;for(const [,id]of html.matchAll(/\bid="([^"]+)"/g)){const n=id==='vc-design-grid'?require('jsdom').JSDOM.fragment(html).querySelector('#vc-design-grid'):node(id,owner);nodes.set(id,n);ids.add(id);}collectionPanel=html.includes('data-vc-layout="collection"')?{closest:selector=>selector==='dialog'&&owner===dialog?dialog:selector==='#home-main'&&owner===main?main:null}:collectionPanel;}
 function renderPage(){if(!main){main=node('home-main');nodes.set('home-main',main);}installHTML(main,extension.pageHTML(),pageIds);}
 const bridge={state,esc:v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),guard(){const id=state.account?.id,g=state.generation;return ()=>id===state.account?.id&&g===state.generation;},request:async(route,body)=>{calls.push({route,body});if(replies.has(route)){const response=replies.get(route);return typeof response==='function'?response(body):await response;}if(route==='/api/cosmetics/catalog')return {items:catalog};if(route==='/api/cosmetics/inventory')return {owned:[],equippedId:null,giftsEnabled:true,pendingGifts:0};if(route.startsWith('/api/cosmetics/recipient?username=')){const username=decodeURIComponent(route.split('=')[1]);return {recipient:{id:'recipient-id',username,displayName:'Recipient'}};}return {owned:[],equippedId:null,giftsEnabled:true,pendingGifts:0};},showDialog(title,copy,html){state.dialogGeneration++;if(dialog)dialog.isConnected=false;clearIds(dialogIds);dialog=node('home-dialog');dialog.open=true;nodes.set('dialog',dialog);nodes.set('home-dialog',dialog);installHTML(dialog,title+copy+html,dialogIds);return state.dialogGeneration;},closeDialog(){state.dialogGeneration++;if(dialog){dialog.open=false;clearIds(dialogIds);}if(!options.page)collectionPanel=null;},announce:text=>announcements.push(text),render(){renders++;if(options.page&&state.view==='collection')renderPage();},registerExtension(value){extension=value;value.init(bridge);}};
 if(options.page){bridge.openPage=name=>{state.view=name;state.generation++;renderPage();Promise.resolve(extension.onPage?.()).catch(error=>{throw error;});return true;};bridge.refreshPage=name=>{if(state.view!==name)return false;renderPage();return true;};}
 const document={documentElement:node('html'),hidden:false,activeElement:null,getElementById:id=>nodes.get(id)||null,querySelector:()=>collectionPanel,addEventListener:(name,handler)=>listeners.set(name,handler)};
 const stubArt={render:(id,mini=false)=>mini?`<svg class="vc-art vc-mini" data-vc-object="${id}" data-vc-kind="decoration" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3h18v18H3Z"/></svg>`:`<span class="vc-art va-asset" data-vc-object="${id}" data-vc-kind="decoration"><img src="/art/v3/${id}-card.fixture.svg" alt="" loading="lazy" width="256" height="256"></span>`,earned:(id,mini=false)=>`<svg class="vc-art${mini?' vc-mini':''}" data-vc-object="${id}" data-vc-kind="earned" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h16v16H4Z"/></svg>`,detail:id=>`<span class="vc-art va-asset" data-vc-object="${id}" data-vc-size="detail"></span>`,mount:async(container,id)=>{artMounts.push({container,id});return null;},preview:async(container,id)=>{artCalls.push({container,id});if(options.previewResult)return await options.previewResult(container,id);container.classList.add('va-playing');const result={played:true,stop(){if(liveArt.has(result)){liveArt.delete(result);artStops.push({container,id});container.classList.remove('va-playing');}}};liveArt.add(result);return result;},stop:container=>{for(const result of [...liveArt]){const entry=artCalls.find(call=>call.container===container);if(entry)result.stop();}},stopAll:()=>{for(const result of [...liveArt])result.stop();}};
 const context={window:{VoidHome:bridge,VoidCollectibleArt:stubArt,...(options.profilePanel?{VoidProfilesPanel:options.profilePanel}:{}),...(options.giftCollections?{VoidGiftCollections:options.giftCollections}:{}),addEventListener(name,fn){windowListeners.set(name,fn);},dispatchEvent(event){windowListeners.get(event.type)?.(event);},matchMedia:()=>media,setTimeout:(fn,ms)=>{timers.set(++timerSerial,{fn,ms});return timerSerial;},clearTimeout:id=>timers.delete(id)},document,crypto:webcrypto,FormData:class{constructor(form){this.values=form.values||{};}get(name){return this.values[name];}},console,Date,URL};
 vm.createContext(context);vm.runInContext(source.replace(/\}\)\(\);\s*$/,'window.__cosmeticsTest={collection,mutate,send,inbox,inspect,reviewSend,transferForm,saveShowcase,showcaseDialog,receivedGift,unwrap,playReveal,playArtwork,endReveal,action,inspectEarned,paintBrowse,summary:()=>({owned:[...owned],equipped,pending,loaded,badgeFilter,kindFilter,seriesFilter,searchQuery,activePanel})};})();'),context);
 return {bridge,state,calls,replies,nodes,listeners,announcements,document,timers,media,windowListeners,artCalls,artStops,artMounts,art:stubArt,seam:context.window.__cosmeticsTest,cosmetics:context.window.VoidCosmetics,get extension(){return extension;},get renders(){return renders;},node};
}

test('free catalog stays unowned until an acknowledged explicit claim',async()=>{
 const app=fixture();await app.extension.onAccount();await app.seam.collection();assert.equal(app.seam.summary().owned.length,0);assert.match(app.nodes.get('dialog').innerHTML,/Add to collection/);assert.match(app.nodes.get('dialog').innerHTML,/Discover/);
 app.replies.set('/api/cosmetics/inventory',{owned:[{cosmetic_id:'angel'}],equippedId:null,giftsEnabled:true,pendingGifts:0});app.replies.set('/api/cosmetics/claim',{owned:[{cosmetic_id:'angel'}],equippedId:null,giftsEnabled:true,pendingGifts:0});await app.seam.mutate('/claim',{cosmeticId:'angel'},app.node(),()=>app.seam.collection());assert.equal(app.seam.summary().owned[0],'angel');
});
test('failed collection writes keep ownership and equipped state unchanged',async()=>{
 const app=fixture();await app.extension.onAccount();await app.seam.collection();app.replies.set('/api/cosmetics/claim',()=>Promise.reject(Error('Write failed')));await app.seam.mutate('/claim',{cosmeticId:'angel'},app.node());assert.equal(app.seam.summary().owned.length,0);assert.equal(app.seam.summary().equipped,null);assert.equal(app.nodes.get('vc-error').textContent,'Write failed');
});
test('a delayed collection load cannot replace a newer profile editor',async()=>{
 const app=fixture(),slow=held();app.replies.set('/api/cosmetics/catalog',slow.promise);const loading=app.seam.collection();app.bridge.showDialog('Edit profile','Unsaved bio','<input id="profile-editor">');slow.resolve({items:[]});await loading;assert.match(app.nodes.get('dialog').innerHTML,/Unsaved bio/);assert.ok(app.nodes.has('profile-editor'));
});
test('old inventory fetches never roll back a later committed equipment change',async()=>{
 const app=fixture();await app.extension.onAccount();const slow=held();app.replies.set('/api/cosmetics/inventory',slow.promise);const loading=app.cosmetics.refresh();app.replies.set('/api/cosmetics/equip',{owned:[{cosmetic_id:'angel'}],equippedId:'angel',giftsEnabled:true,pendingGifts:0});await app.seam.mutate('/equip',{cosmeticId:'angel'},app.node());slow.resolve({owned:[],equippedId:null,giftsEnabled:true,pendingGifts:0});await loading;assert.equal(app.seam.summary().equipped,'angel');assert.equal(app.seam.summary().owned.length,1);
});
test('collection mutations do not rebuild an active conversation composer',async()=>{
 for(const field of ['secureRoomId','nativeId','channelId']){const app=fixture();await app.extension.onAccount();app.state[field]='private-room';const before=app.renders;app.replies.set('/api/cosmetics/claim',{owned:[{cosmetic_id:'angel'}],equippedId:null,giftsEnabled:true,pendingGifts:0});await app.seam.mutate('/claim',{cosmeticId:'angel'},app.node());assert.equal(app.renders,before,field);}
});
test('old-account inventory and mutation acknowledgments cannot enter a different account',async()=>{
 const app=fixture(),slow=held();await app.extension.onAccount();app.replies.set('/api/cosmetics/equip',slow.promise);const saving=app.seam.mutate('/equip',{cosmeticId:'angel'},app.node());app.extension.onLock();app.state.account={id:'account-b'};await app.extension.onAccount();slow.resolve({owned:[{cosmetic_id:'angel'}],equippedId:'angel',giftsEnabled:true,pendingGifts:99});await saving;assert.equal(app.seam.summary().equipped,null);assert.equal(app.seam.summary().pending,0);
});
test('failed gift sends preserve the form and retry with the same client request ID',async()=>{
 const app=fixture();await app.extension.onAccount();app.bridge.showDialog('Send gift','','<p id="vc-error"></p>');let attempts=0;app.replies.set('/api/cosmetics/gifts',body=>{attempts++;if(attempts===1)throw Error('Connection lost');return {acknowledged:true,gift:{id:'actual-gift'}};});const form=app.node();form.dataset={item:'gift-rose',client:'stable-gift-id'};form.values={username:'recipient'};await app.seam.send(form);assert.match(app.nodes.get('vc-error').textContent,/Connection lost/);assert.equal(form.dataset.client,'stable-gift-id');await app.seam.send(form);const sends=app.calls.filter(call=>call.route==='/api/cosmetics/gifts');assert.equal(sends.length,2);assert.equal(sends[0].body.clientId,sends[1].body.clientId);assert.match(app.nodes.get('dialog').innerHTML,/Gift request sent/);
});
test('reviewing a gift names its recipient and item without sending or changing the retry ID',async()=>{
 const app=fixture();await app.extension.onAccount();const form=app.node();form.dataset={vcForm:'send',item:'gift-rose',client:'review-client-001'};form.values={username:'@recipient'};await app.seam.reviewSend(form);const html=app.nodes.get('dialog').innerHTML;assert.match(html,/Review gift/);assert.match(html,/Chrome Rose/);assert.match(html,/value="recipient"/);assert.match(html,/data-client="review-client-001"/);assert.match(html,/Confirm free gift/);assert.match(html,/Private notes are unavailable/);assert.equal(app.calls.filter(c=>c.route==='/api/cosmetics/gifts').length,0);
});
test('an owned-instance transfer reviews distinct ownership behavior and uses the instance endpoint',async()=>{
 const app=fixture();app.replies.set('/api/cosmetics/inventory',{instances:[{id:'instance-original',catalog_id:'gift-rose',origin_kind:'claim',created_at:1}],owned:[{cosmetic_id:'gift-rose'}]});await app.extension.onAccount();app.seam.transferForm('instance-original');assert.match(app.nodes.get('dialog').innerHTML,/Ownership moves only after acceptance/);const original=app.node();original.dataset={vcForm:'transfer',instance:'instance-original',item:'gift-rose',client:'transfer-client-01'};original.values={username:'recipient'};await app.seam.reviewSend(original);assert.match(app.nodes.get('dialog').innerHTML,/Confirm gift transfer/);assert.match(app.nodes.get('dialog').innerHTML,/data-instance="instance-original"/);app.replies.set('/api/cosmetics/transfers',{acknowledged:true,transfer:{id:'transfer-receipt'}});const confirm=app.node();confirm.dataset={mode:'transfer',instance:'instance-original',item:'gift-rose',client:'transfer-client-01'};confirm.values={username:'recipient'};await app.seam.send(confirm);const request=app.calls.find(c=>c.route==='/api/cosmetics/transfers');assert.equal(request.body.instanceId,'instance-original');assert.equal(request.body.catalogId,undefined);assert.match(app.nodes.get('dialog').innerHTML,/transfer-receipt/);assert.match(app.nodes.get('dialog').innerHTML,/data-vc-action="transfers" data-box="sent"/);assert.match(app.nodes.get('dialog').innerHTML,/View sent transfers/);
});
test('a missing server gift acknowledgement never shows a sent receipt',async()=>{
 const app=fixture();await app.extension.onAccount();app.bridge.showDialog('Review gift','','<p id="vc-error"></p>');app.replies.set('/api/cosmetics/gifts',{acknowledged:false});const form=app.node();form.dataset={item:'gift-rose',client:'ack-client-001'};form.values={username:'recipient'};await app.seam.send(form);assert.match(app.nodes.get('vc-error').textContent,/not acknowledged/);assert.doesNotMatch(app.nodes.get('dialog').innerHTML,/Gift request sent/);assert.equal(app.announcements.length,0);
});
test('a showcase edit submits only the chosen slots and explicit sender disclosure',async()=>{
 const app=fixture();app.replies.set('/api/cosmetics/inventory',{instances:[{id:'owned-instance',catalog_id:'gift-rose'}],showcase:[{slot:1,instance_id:'original-slot',show_sender:0}],owned:[]});await app.extension.onAccount();app.seam.showcaseDialog('owned-instance');assert.match(app.nodes.get('dialog').innerHTML,/Sender identity stays hidden/);app.replies.set('/api/cosmetics/showcase',()=>Promise.reject(Error('Showcase not saved')));const form=app.node();form.dataset={instance:'owned-instance'};form.values={slot:'2',showSender:'on'};await app.seam.saveShowcase(form);const request=app.calls.find(c=>c.route==='/api/cosmetics/showcase');assert.equal(request.body.slots.length,2);assert.equal(request.body.slots[0].showSender,false);assert.equal(request.body.slots[1].instanceId,'owned-instance');assert.equal(request.body.slots[1].showSender,true);assert.match(app.nodes.get('vc-error').textContent,/Showcase not saved/);
});
test('series filters show the exact server catalog subset without claiming any badges',async()=>{
 const catalog=[{id:'angel',type:'badge',category:'originals',name:'404 Angel',finish:'Chrome',price:0},{id:'coin-crosssignal',type:'badge',category:'crypto',series:'Chain Signals',name:'Cross Signal',finish:'Chrome',acquisition:'No coins, wallet holdings or official affiliation.',price:0},{id:'meme-grass',type:'badge',category:'memes',series:'Internet Relics',name:'Touch Grass',finish:'Jade enamel',price:0}];
 const app=fixture({catalog});await app.extension.onAccount();
 await app.seam.collection('badges','crypto');let html=app.nodes.get('dialog').innerHTML;assert.match(html,/Cross Signal/);assert.doesNotMatch(html,/>404 Angel</);assert.doesNotMatch(html,/>Touch Grass</);assert.match(html,/1 design · 0 collected/);assert.match(html,/profile art, not tokens or wallet holdings/);assert.match(html,/data-filter="crypto" aria-pressed="true"/);
 app.seam.inspect('coin-crosssignal');assert.match(app.nodes.get('dialog').innerHTML,/No coins, wallet holdings or official affiliation/);assert.match(app.nodes.get('dialog').innerHTML,/VOIDLINE collection artwork/);
 await app.seam.collection('badges','memes');html=app.nodes.get('dialog').innerHTML;assert.match(html,/Touch Grass/);assert.doesNotMatch(html,/>Cross Signal</);
 await app.seam.collection('badges','owned');assert.match(app.nodes.get('dialog').innerHTML,/No collected items yet/);assert.equal(app.calls.filter(call=>call.body).length,0);
 app.replies.set('/api/cosmetics/inventory',{owned:[{cosmetic_id:'coin-crosssignal'}]});app.replies.set('/api/cosmetics/claim',{owned:[{cosmetic_id:'coin-crosssignal'}]});await app.seam.mutate('/claim',{cosmeticId:'coin-crosssignal'},app.node());await app.seam.collection('badges','owned');assert.match(app.nodes.get('dialog').innerHTML,/Cross Signal/);assert.match(app.nodes.get('dialog').innerHTML,/1 design · 1 collected/);
 app.extension.onLock();app.state.account={id:'account-b'};app.replies.set('/api/cosmetics/inventory',{owned:[]});await app.extension.onAccount();assert.equal(app.seam.summary().badgeFilter,'all');assert.equal(app.seam.summary().owned.length,0);
});
test('earned awards have dedicated art and detail provenance from server award records',async()=>{
 const app=fixture();await app.extension.onAccount();app.replies.set('/api/cosmetics/badges',{definitions:[{id:'profile-authored',name:'Profile Authored',description:'Profile achievement',requirement:'Real committed profile.'},{id:'reviewed-contribution',name:'Community Contribution',description:'Reviewed contribution',requirement:'Reviewed by verified owner.'}],awards:[{badge_id:'profile-authored',valid:true,issued_at:1700000000000,issuer:'VOIDLINE server rule'}]});await app.cosmetics.badgeDirectory();assert.match(app.nodes.get('vc-earned-list').innerHTML,/data-vc-object="profile-authored"/);assert.doesNotMatch(app.nodes.get('vc-earned-list').innerHTML,/data-vc-object="angel"|data-vc-object="voidwalker"/);app.seam.inspectEarned('profile-authored');assert.match(app.nodes.get('dialog').innerHTML,/Earned and valid/);assert.match(app.nodes.get('dialog').innerHTML,/VOIDLINE server rule/);assert.match(app.nodes.get('dialog').innerHTML,/Real committed profile/);assert.match(app.nodes.get('dialog').innerHTML,/Not transferable/);
 assert.match(app.cosmetics.earnedArt('reviewed-contribution',true),/data-vc-kind="earned"/);
 assert.equal(app.calls.filter(call=>call.body).length,0);
});
test('collection returns to its account-scoped filter and saved scroll position',async()=>{
 const app=fixture({catalog:[{id:'coin-crosssignal',type:'badge',category:'crypto',name:'Cross Signal',finish:'Chrome',description:'Long description belongs in inspection.',acquisition:'Free decoration.'}]});await app.extension.onAccount();await app.seam.collection('badges','crypto');app.nodes.get('dialog').scrollTop=420;app.seam.inspect('coin-crosssignal');assert.match(app.nodes.get('dialog').innerHTML,/Long description belongs in inspection/);await app.seam.action({dataset:{vcAction:'return',tab:'badges',item:'coin-crosssignal'}});assert.equal(app.nodes.get('dialog').scrollTop,420);assert.match(app.nodes.get('dialog').innerHTML,/data-filter="crypto" aria-pressed="true"/);assert.doesNotMatch(app.nodes.get('dialog').innerHTML,/Long description belongs in inspection/);app.extension.onLock();app.state.account={id:'account-b'};await app.extension.onAccount();await app.seam.collection('badges','crypto');assert.equal(app.nodes.get('dialog').scrollTop,0);
 assert.match(css,/@container collection/);assert.match(css,/repeat\(auto-fill,minmax\(min\(100%/);assert.match(css,/vc-layout="collection"/);assert.doesNotMatch(css,/@media\(max-width:700px\).*vc-grid/);
});
test('accepting a gift requires the confirmed exact owned instance before a static receipt and optional replay',async()=>{
 const app=fixture();await app.extension.onAccount();app.bridge.showDialog('Gift requests','','<p id="vc-error"></p>');const button=app.node();button.dataset={item:'gift-rose',gift:'receipt-id'};app.replies.set('/api/cosmetics/gifts/receipt-id/open',{handled:false,owned:[]});await app.seam.receivedGift(button);assert.doesNotMatch(app.nodes.get('dialog').innerHTML,/vc-reveal/);assert.match(app.nodes.get('vc-error').textContent,/not confirmed/);
 app.replies.set('/api/cosmetics/gifts/receipt-id/open',{handled:true,owned:[{cosmetic_id:'gift-rose'}],instances:[{id:'gift:receipt-id',catalog_id:'gift-rose'}]});await app.seam.receivedGift(button);assert.match(app.nodes.get('dialog').innerHTML,/Accepted free gift/);assert.match(app.nodes.get('dialog').innerHTML,/gift:receipt-id/);assert.equal(app.artCalls.length,0);await app.seam.playReveal();assert.equal(app.artCalls.length,1);assert.equal(app.artCalls[0].id,'gift-rose');assert.equal(app.nodes.get('vc-reveal').classList.contains('va-playing'),true);app.seam.endReveal();assert.equal(app.artStops.length,1);assert.equal(app.nodes.get('vc-reveal').classList.contains('va-playing'),false);
});

test('accepted transfers preserve their existing instance receipt and never show a new grant',async()=>{
 const app=fixture();await app.extension.onAccount();app.bridge.showDialog('Incoming transfer','','<p id="vc-error"></p>');const button=app.node();button.dataset={item:'gift-rose',instance:'existing-instance',transfer:'transfer-id'};app.replies.set('/api/cosmetics/transfers/transfer-id/open',{handled:true,state:'accepted',owned:[{cosmetic_id:'gift-rose'}],instances:[{id:'existing-instance',catalog_id:'gift-rose'}]});await app.seam.receivedGift(button,true);assert.match(app.nodes.get('dialog').innerHTML,/Accepted transfer/);assert.match(app.nodes.get('dialog').innerHTML,/existing-instance/);assert.doesNotMatch(app.nodes.get('dialog').innerHTML,/Accepted free gift/);
});
test('app and OS reduced motion independently suppress optional reveals; lock clears acceptance',async()=>{
 for(const mode of ['os','app']){const app=fixture({osReduced:mode==='os'});await app.extension.onAccount();app.bridge.showDialog('Requests','','<p id="vc-error"></p>');const button=app.node();button.dataset={item:'gift-rose',gift:'safe-receipt'};app.replies.set('/api/cosmetics/gifts/safe-receipt/open',{handled:true,owned:[{cosmetic_id:'gift-rose'}],instances:[{id:'gift:safe-receipt',catalog_id:'gift-rose'}]});await app.seam.receivedGift(button);if(mode==='app')app.document.documentElement.classList.add('vh-reduced-motion');await app.seam.playReveal();assert.equal(app.timers.size,0);assert.equal(app.nodes.get('vc-reveal').classList.contains('vc-revealing'),false);assert.match(app.announcements.at(-1),/reduced motion/);app.extension.onLock();app.state.account={id:'account-b'};await app.extension.onAccount();assert.throws(()=>app.seam.unwrap('gift-rose'),/confirm this gift/);}
 assert.match(css,/html\.vh-reduced-motion/);assert.match(css,/@media\(prefers-reduced-motion:reduce\)/);assert.match(css,/animation:none!important/);assert.doesNotMatch(css,/@keyframes vc-open|animation:[^;}]*infinite/);
});

test('active previews stop on page navigation, backgrounding and replacement without transaction calls',async()=>{
 const app=fixture();await app.extension.onAccount();await app.seam.collection();app.seam.inspect('gift-rose');await app.seam.playArtwork(app.nodes.get('vc-inspection-scene'),'gift-rose');assert.equal(app.artCalls.length,1);app.document.hidden=true;app.listeners.get('visibilitychange')();assert.equal(app.artStops.length,1);app.document.hidden=false;await app.seam.playArtwork(app.nodes.get('vc-inspection-scene'),'gift-rose');app.extension.onPageLeave();assert.equal(app.artStops.length,2);await app.seam.playArtwork(app.nodes.get('vc-inspection-scene'),'gift-rose');app.seam.inspect('angel');assert.equal(app.artStops.length,3);assert.equal(app.calls.filter(call=>call.body).length,0);
});

test('filtering preserves the actual matched poster nodes and restores temporarily hidden designs',async()=>{
 const app=fixture();await app.seam.collection();const grid=app.nodes.get('vc-design-grid'),rose=grid.querySelector('[data-design-id="gift-rose"] img'),angel=grid.querySelector('[data-design-id="angel"] img');
 const input=app.node();input.dataset.vcSearch='';input.value='rose';app.listeners.get('input')({target:input});
 assert.equal(grid.children.length,1);assert.equal(grid.querySelector('img'),rose);input.value='';app.listeners.get('input')({target:input});
 assert.equal(grid.children.length,2);assert.equal(grid.querySelector('[data-design-id="angel"] img'),angel);assert.equal(grid.querySelector('[data-design-id="gift-rose"] img'),rose);
});
test('dedicated collection is a page and preserves search, type, series, scroll and focus across inspection and return',async()=>{
 const catalog=[{id:'angel',type:'badge',category:'originals',series:'VOIDLINE Originals',name:'404 Angel',finish:'Aluminium',description:'Feathers'},{id:'gift-rose',type:'gift',category:'gifts',series:'Afterhours Objects',name:'Chrome Rose',finish:'Nickel',description:'Folded rose'}],app=fixture({page:true,catalog});await app.extension.onAccount();await app.seam.collection();assert.equal(app.state.view,'collection');assert.equal(app.nodes.has('dialog'),false);assert.match(app.nodes.get('home-main').innerHTML,/Discover/);assert.equal(app.extension.navHTML(),'');
 const kind=app.node();kind.value='gift';kind.setAttribute('data-vc-kind','');app.listeners.get('change')({target:kind});const series=app.node();series.value='Afterhours Objects';series.setAttribute('data-vc-series','');app.listeners.get('change')({target:series});const search=app.nodes.get('vc-design-search');search.dataset.vcSearch='';search.value='rose';app.listeners.get('input')({target:search});app.nodes.get('home-main').scrollTop=312;
 const cached=app.extension.pageHTML();assert.match(cached,/value="rose"/);assert.match(cached,/value="gift" selected/);assert.match(cached,/Afterhours Objects" selected/);assert.match(cached,/Chrome Rose/);assert.doesNotMatch(cached,/>404 Angel</);
 app.seam.inspect('gift-rose');await app.seam.action({dataset:{vcAction:'return',item:'gift-rose'}});assert.equal(app.nodes.get('home-main').scrollTop,312);assert.equal(app.document.activeElement.dataset.item,'gift-rose');app.extension.onPageLeave();app.state.view='chats';app.state.view='collection';await app.extension.onPage();assert.match(app.extension.pageHTML(),/value="rose"/);assert.equal(app.seam.summary().kindFilter,'gift');assert.equal(app.seam.summary().seriesFilter,'Afterhours Objects');assert.equal(app.calls.filter(call=>call.body).length,0);
});
test('loaded gift and earned page contents survive unrelated application rerenders',async()=>{
 const app=fixture({page:true});await app.extension.onAccount();app.replies.set('/api/cosmetics/gifts?box=sent&offset=0',{gifts:[{id:'gift-one',catalog_id:'gift-rose',recipient_username:'recipient',state:'pending',created_at:1}],total:1,page:{hasMore:false}});await app.seam.inbox('sent');assert.match(app.extension.pageHTML(),/To @recipient/);assert.doesNotMatch(app.extension.pageHTML(),/Loading gifts…/);app.bridge.render();assert.match(app.nodes.get('home-main').innerHTML,/To @recipient/);
 app.replies.set('/api/cosmetics/badges',{definitions:[{id:'profile-authored',name:'Profile Authored',description:'Authored profile',requirement:'A real committed profile.'}],awards:[]});await app.cosmetics.badgeDirectory();assert.match(app.extension.pageHTML(),/A real committed profile/);assert.match(app.extension.pageHTML(),/Not earned/);app.bridge.render();assert.match(app.nodes.get('home-main').innerHTML,/A real committed profile/);assert.doesNotMatch(app.nodes.get('home-main').innerHTML,/Loading badge directory…/);
});
test('collection navigation, edition labels and gift requests stay consistent when inventory stalls',async()=>{
 const {JSDOM}=require('jsdom'),app=fixture({page:true}),slow=held();
 app.replies.set('/api/cosmetics/inventory',slow.promise);
 app.replies.set('/api/cosmetics/gifts?box=inbox&offset=0',{gifts:[{id:'r',catalog_id:'gift-rose',state:'pending',sender_username:'river',created_at:1}],total:1,page:{hasMore:false}});
 await app.seam.inbox();
 const markup=JSDOM.fragment(app.extension.pageHTML());
 assert.deepEqual([...markup.querySelectorAll('.vc-hub-tabs button')].map(b=>b.textContent),['My gifts','Discover','Earn','Requests']);
 assert.equal(markup.querySelector('.vc-hub-tabs [aria-current="page"]').textContent,'Requests');
 assert.match(markup.querySelector('#vc-gift-list').textContent,/@river/);
 assert(markup.querySelector('[data-vc-action="open"]'));
 slow.resolve({owned:[]});await new Promise(resolve=>setImmediate(resolve));
 assert.match(app.extension.pageHTML(),/Free edition/);
});
test('a late page response cannot replace a newer section or enter its cached markup',async()=>{
 const app=fixture({page:true}),slow=held();await app.extension.onAccount();app.replies.set('/api/cosmetics/gifts?box=inbox&offset=0',slow.promise);const pending=app.seam.inbox();await app.seam.collection('browse');slow.resolve({gifts:[{id:'late',catalog_id:'gift-rose',sender_username:'late_sender',state:'pending',created_at:1}],total:1,page:{hasMore:false}});await pending;assert.equal(app.seam.summary().activePanel,'browse');assert.doesNotMatch(app.extension.pageHTML(),/late_sender|Loading gifts/);assert.match(app.extension.pageHTML(),/Discover/);
});
test('inspection failures target the visible dialog rather than the collection page under it',async()=>{
 const app=fixture({page:true});await app.extension.onAccount();await app.seam.collection();assert.ok(app.nodes.has('vc-page-error'));app.seam.inspect('angel');app.replies.set('/api/cosmetics/claim',()=>{throw Error('Claim unavailable');});await app.seam.mutate('/claim',{cosmeticId:'angel'},app.node());assert.equal(app.nodes.get('vc-error').textContent,'Claim unavailable');assert.equal(app.nodes.get('vc-page-error').textContent,'');assert.equal((app.extension.pageHTML().match(/id="vc-error"/g)||[]).length,0);
});
test('catalog art previews remain available before ownership and never issue a collection transaction',async()=>{
 const app=fixture();await app.extension.onAccount();await app.seam.collection();app.seam.inspect('gift-rose');assert.match(app.nodes.get('dialog').innerHTML,/Preview animation/);assert.match(app.nodes.get('dialog').innerHTML,/Not collected/);await app.seam.action({dataset:{vcAction:'preview',item:'gift-rose',stage:'vc-inspection-scene'}});assert.equal(app.artCalls.length,1);assert.equal(app.seam.summary().owned.length,0);assert.equal(app.calls.filter(call=>call.body).length,0);
});
test('failed and late previews show a still fallback and are stopped when account context changes',async()=>{
 const unavailable=fixture({previewResult:async()=>({played:false,reason:'unavailable'})});await unavailable.extension.onAccount();unavailable.seam.inspect('angel');await unavailable.seam.playArtwork(unavailable.nodes.get('vc-inspection-scene'),'angel');assert.match(unavailable.nodes.get('vc-preview-feedback').textContent,/still artwork remains/);
 const legacy=fixture();await legacy.extension.onAccount();legacy.seam.inspect('angel');delete legacy.art.preview;await legacy.seam.playArtwork(legacy.nodes.get('vc-inspection-scene'),'angel');assert.match(legacy.nodes.get('vc-preview-feedback').textContent,/still artwork remains/);assert.equal(legacy.timers.size,0);
 const pending=held();let stops=0;const app=fixture({previewResult:()=>pending.promise});await app.extension.onAccount();app.seam.inspect('angel');const playing=app.seam.playArtwork(app.nodes.get('vc-inspection-scene'),'angel');app.extension.onLock();app.state.account={id:'account-b'};await app.extension.onAccount();pending.resolve({played:true,stop(){stops++;}});await playing;assert.equal(stops,1);assert.equal(app.calls.filter(call=>call.body).length,0);
});
test('recipient preflight is coalesced and the confirmed action includes the reviewed immutable identity',async()=>{
 const app=fixture(),pending=held();await app.extension.onAccount();app.replies.set('/api/cosmetics/recipient?username=recipient',pending.promise);const form=app.node();form.dataset={vcForm:'send',item:'gift-rose',client:'review-stable-id'};form.values={username:'@recipient'};const first=app.seam.reviewSend(form),second=app.seam.reviewSend(form);assert.equal(app.calls.filter(call=>call.route.includes('/recipient?')).length,1);assert.equal(app.calls.filter(call=>call.body).length,0);pending.resolve({recipient:{id:'immutable-recipient',username:'recipient',displayName:'A chosen recipient'}});await Promise.all([first,second]);const html=app.nodes.get('dialog').innerHTML;assert.match(html,/A chosen recipient/);assert.match(html,/data-recipient="immutable-recipient"/);assert.match(html,/data-client="review-stable-id"/);
 app.replies.set('/api/cosmetics/gifts',{acknowledged:true,gift:{id:'durable-gift'}});const confirm=app.node();confirm.dataset={item:'gift-rose',client:'review-stable-id',recipient:'immutable-recipient'};confirm.values={username:'recipient'};await app.seam.send(confirm);const request=app.calls.find(call=>call.route==='/api/cosmetics/gifts');assert.equal(request.body.recipientId,'immutable-recipient');assert.equal(request.body.clientId,'review-stable-id');
});
test('failed or stale recipient lookup retains input and cannot replace a newer editor or send a gift',async()=>{
 const app=fixture();await app.extension.onAccount();app.bridge.showDialog('Send gift','','<p id="vc-error"></p>');const form=app.node();form.dataset={vcForm:'send',item:'gift-rose',client:'review-input-id'};form.values={username:'recipient'};app.replies.set('/api/cosmetics/recipient?username=recipient',()=>{throw Error('Recipient unavailable');});await app.seam.reviewSend(form);assert.equal(form.values.username,'recipient');assert.equal(form.dataset.client,'review-input-id');assert.equal(form.dataset.reviewBusy,undefined);assert.match(app.nodes.get('vc-error').textContent,/Recipient unavailable/);
 const pending=held();app.replies.set('/api/cosmetics/recipient?username=recipient',pending.promise);const reviewing=app.seam.reviewSend(form);app.bridge.showDialog('Edit profile','Unsaved bio','<input id="new-editor">');pending.resolve({recipient:{id:'new-id',username:'recipient'}});await reviewing;assert.ok(app.nodes.has('new-editor'));assert.doesNotMatch(app.nodes.get('dialog').innerHTML,/Review gift/);assert.equal(app.calls.filter(call=>call.body).length,0);
});
test('earned artwork inspection previews do not award the achievement',async()=>{
 const app=fixture();await app.extension.onAccount();app.replies.set('/api/cosmetics/badges',{definitions:[{id:'profile-authored',name:'Profile Authored',description:'Profile achievement',requirement:'A real requirement.'}],awards:[]});await app.cosmetics.badgeDirectory();app.seam.inspectEarned('profile-authored');assert.match(app.nodes.get('dialog').innerHTML,/Not earned/);await app.seam.action({dataset:{vcAction:'preview',item:'profile-authored',stage:'vc-earned-scene'}});assert.equal(app.artCalls.at(-1).id,'profile-authored');assert.equal(app.calls.filter(call=>call.body).length,0);
});
test('retired owned designs preserve their ownership label and inspection without advertising a new gift grant',async()=>{
 const app=fixture({page:true,catalog:[{id:'gift-rose',type:'gift',name:'Chrome Rose',series:'Afterhours Objects',finish:'Nickel',description:'Folded metal',active:false}]});app.replies.set('/api/cosmetics/inventory',{owned:[{cosmetic_id:'gift-rose'}],instances:[{id:'owned-retired',catalog_id:'gift-rose'}]});await app.extension.onAccount();await app.seam.collection('collected');assert.match(app.extension.pageHTML(),/Collected · Retired design/);app.seam.inspect('gift-rose');assert.match(app.nodes.get('dialog').innerHTML,/Existing ownership is preserved/);assert.match(app.nodes.get('dialog').innerHTML,/1 owned instance/);assert.doesNotMatch(app.nodes.get('dialog').innerHTML,/data-vc-action="send-form"|Add to collection · Free/);assert.equal(app.calls.filter(call=>call.body).length,0);
});
test('closed inspection markup cannot redirect a page claim into a stale profile callback',async()=>{
 const app=fixture({page:true});await app.extension.onAccount();await app.seam.collection();let profileReturns=0;app.seam.inspect('angel',{returnTo:()=>profileReturns++});app.nodes.get('home-dialog').open=false;app.replies.set('/api/cosmetics/claim',{owned:[{cosmetic_id:'angel'}],equippedId:null});await app.seam.action({dataset:{vcAction:'claim',item:'angel'}});assert.equal(profileReturns,0);assert.equal(app.state.view,'collection');assert.match(app.extension.pageHTML(),/Discover/);assert.equal(app.nodes.get('home-dialog').open,false);
});
test('account switching clears cached collection content and its prior filter context',async()=>{
 const app=fixture({page:true});app.replies.set('/api/cosmetics/inventory',{owned:[{cosmetic_id:'angel'}],equippedId:'angel'});await app.extension.onAccount();await app.seam.collection('collected');assert.match(app.extension.pageHTML(),/Equipped/);app.extension.onLock();app.state.account={id:'account-b'};app.replies.set('/api/cosmetics/inventory',{owned:[],equippedId:null});await app.extension.onAccount();assert.doesNotMatch(app.extension.pageHTML(),/Equipped|value="rose"/);await app.seam.collection('collected');assert.match(app.extension.pageHTML(),/Your collection starts empty/);assert.equal(app.seam.summary().owned.length,0);
});

test('a capsule-only model exposes its actual identity without a free claim or new-grant control',async()=>{
 const model={id:'gift-pepe-desk-green',type:'gift',name:'Desk Green',familyName:'Pepe Keycap',tier:'Common',material:'Molded green plastic',motif:'Key legends',backdrop:{name:'Warm Terminal'},acquisitionPolicy:'capsule-only'};
 const f=fixture({catalog:[model]});await f.extension.onAccount();await f.seam.collection();let html=f.nodes.get('dialog').innerHTML;
 assert.match(html,/Earned capsule model/);assert.doesNotMatch(html,/data-vc-action="claim"/);
 f.seam.inspect(model.id);html=f.nodes.get('dialog').innerHTML;
 for(const value of ['Desk Green','Pepe Keycap','Common','Key legends','Warm Terminal'])assert(html.includes(value));
 assert.doesNotMatch(html,/data-vc-action="(?:claim|send-form|transfer-form|showcase)"|Free to collect/);
});
test('a terminal transfer missing from bootstrap uses its participant receipt without replaying acceptance',async()=>{
 const f=fixture();await f.extension.onAccount();const t={id:'tx',instance_id:'copy',catalog_id:'gift-rose',state:'accepted',model:{name:'Chrome Rose'},currentlyOwned:false};
 f.replies.set('/api/cosmetics/transfers/tx',{transfer:t});f.replies.set('/api/cosmetics/transfers/tx/open',{handled:true,state:'accepted',transfer:t,instances:[],owned:[]});
 const b=f.node();b.dataset={item:'gift-rose',instance:'copy',transfer:'tx'};await f.seam.receivedGift(b,true);const html=f.nodes.get('dialog').innerHTML;
 assert.match(html,/Accepted gift receipt/);assert.match(html,/Replay gift/);assert.doesNotMatch(html,/View owned copy|data-vc-action="transfer-open"/);
 assert.equal(f.calls.filter(r=>r.route.endsWith('/open')).length,1);
});
(async()=>{test('a signed-in design link opens the exact item or server-defined award without a collection mutation',async()=>{
 const app=fixture({page:true});
 await app.extension.onAccount();
 assert.equal(await app.cosmetics.openDesign('gift-rose'),true);
 assert.match(app.nodes.get('dialog').innerHTML,/Chrome Rose/);
 app.replies.set('/api/cosmetics/badges',{definitions:[{id:'profile-authored',name:'Profile Authored',description:'Known requirement',requirement:'Save a profile.'}],awards:[]});
 assert.equal(await app.cosmetics.openDesign('profile-authored'),true);
 assert.match(app.nodes.get('dialog').innerHTML,/Profile Authored/);
 assert.equal(await app.cosmetics.openDesign('does-not-exist'),false);
 assert.equal(await app.cosmetics.openDesign('bad/path'),false);
 assert.equal(app.calls.filter(call=>call.body).length,0);
});
test('the actual expanded catalog exposes recognizable names and keeps former names searchable without changing ownership',async()=>{
 const {COSMETICS}=await import('../worker/cosmetics.mjs');const app=fixture({page:true,catalog:COSMETICS});await app.extension.onAccount();await app.seam.collection();
 assert.match(app.extension.pageHTML(),new RegExp('49 decorations · '+COSMETICS.filter(item=>item.type==='gift').length+' gifts'));assert.equal(app.seam.summary().owned.length,0);
 const input=app.node();input.dataset.vcSearch='';
 const renamed=[['coin-crosssignal','XRP','Cross Signal'],['ego-unique-one','Max Stirner','The Unique One'],['meme-nothing-happens','Chudjak','Nothing Ever Happens'],['meme-final-reply','Reply Guy','Final Reply']];
 for(const [id,name,alias]of renamed)for(const query of [name,alias]){input.value=query;app.listeners.get('input')({target:input});const html=app.nodes.get('vc-design-grid').innerHTML;assert(html.includes('data-item="'+id+'"'),query);assert(html.includes('>'+name+'<'),query);}
 for(const [id,name]of [['meme-chud','CHUD'],['meme-wojak','Wojak'],['meme-soyjak','Soyjak'],['meme-gigachad','Gigachad'],['meme-cope-seethe','Cope & Seethe'],['meme-pepe','Pepe']]){input.value=name;app.listeners.get('input')({target:input});assert(app.nodes.get('vc-design-grid').innerHTML.includes('data-item="'+id+'"'),name);app.seam.inspect(id);assert(app.nodes.get('dialog').innerHTML.includes('<h3>'+app.bridge.esc(name)+'</h3>'));app.bridge.closeDialog();}
 assert.equal(app.calls.filter(call=>call.body).length,0);assert.equal(app.seam.summary().owned.length,0);
});
test('the Copium family keeps original free designs and distinguishes capsule editions in Discover',async()=>{
 const {COSMETICS}=await import('../worker/cosmetics.mjs');
 const {JSDOM}=require('jsdom');
 const app=fixture({page:true,catalog:COSMETICS});
 const ids=['rain-check','second-wind','hold-music','panic-button','last-resort'].map(name=>'gift-cartridge-'+name);
 await app.extension.onAccount();
 await app.extension.handleAction('cosmetics-collection');
 const browse=JSDOM.fragment(app.extension.pageHTML());
 const series=browse.querySelector('[data-vc-series]');
 assert([...series.options].some(option=>option.value==='Copium Cartridges'));
 const original=browse.querySelector('[data-vc-action="inspect"][data-item="gift-copium-cartridge"]');
 await app.seam.action(original);
 const related=JSDOM.fragment(app.nodes.get('dialog').innerHTML).querySelector('[data-vc-action="browse-series"]');
 assert.equal(related.textContent,'Browse Copium Cartridges');
 await app.seam.action(related);
 const results=JSDOM.fragment(app.extension.pageHTML());
 assert.equal(results.querySelector('[data-vc-series]').value,'Copium Cartridges');
 assert.equal(results.querySelector('[data-vc-kind]').value,'gift');
 const cards=[...results.querySelectorAll('[data-design-id]')];
 const capsuleIDs=COSMETICS.filter(item=>item.familyId==='copium-cartridge').map(item=>item.id);
 assert.deepEqual(cards.map(card=>card.dataset.designId).sort(),['gift-copium-cartridge',...ids,...capsuleIDs].sort());
 for(const card of cards){
  const label=card.querySelector('.vc-series').textContent;
  if(capsuleIDs.includes(card.dataset.designId)){
   assert.match(label,/Capsule edition/);
   assert.equal(card.querySelector('[data-vc-action="claim"]'),null);
  }else assert.match(label,/Free edition/);
 }
 for(const card of cards){
  const catalogDesign=COSMETICS.find(item=>item.id===card.dataset.designId);
  assert.equal(card.querySelector('h3').textContent,catalogDesign.name);
  assert.equal(card.querySelector('.vc-art-button').getAttribute('aria-label'),'Inspect '+catalogDesign.name);
 }
 assert.equal(results.querySelectorAll('[data-vc-action="claim"]').length,6);
 const design=results.querySelector('[data-vc-action="inspect"][data-item="gift-cartridge-rain-check"]');
 await app.seam.action(design);
 const send=JSDOM.fragment(app.nodes.get('dialog').innerHTML).querySelector('[data-vc-action="send-form"]');
 await app.seam.action(send);
 const form=JSDOM.fragment(app.nodes.get('dialog').innerHTML).querySelector('[data-vc-form="send"]');
 assert.equal(form.dataset.item,design.dataset.item);
 assert.equal(app.calls.filter(call=>call.body).length,0);
});
test('original gift inspections explain their cosmetic acquisition and preview without source NFT links or transactions',async()=>{
 const {COSMETICS}=await import('../worker/cosmetics.mjs');const app=fixture({catalog:COSMETICS});await app.extension.onAccount();await app.seam.collection('gifts');
 assert.doesNotMatch(app.nodes.get('dialog').innerHTML,/gift-telegram-|Telegram studies|Plush Pepe|Jelly Bunny|Astral Shard|Heroic Helmet|Skull Flower|Vintage Cigar|Lol Pop/);
 const ids=['gift-chudjak-plush','gift-wojak-jelly','gift-doomer-bloom','gift-brainrot-pop','gift-larp-cap','gift-spook-crystal','gift-larp-helmet','gift-copium-cartridge'];
 for(const id of ids){app.seam.inspect(id);const html=app.nodes.get('dialog').innerHTML;assert.match(html,/Free VOIDLINE cosmetic instance/);assert.match(html,COSMETICS.find(item=>item.id===id).artwork?/credited web artwork/:/original workshop artwork/);assert.match(html,/no blockchain asset changes hands/i);assert.match(html,/Not collected/);assert.doesNotMatch(html,/https:\/\/t\.me\/nft\/|data-vc-reference|Amalgam|King Leonidas|Silver Bullet/);await app.seam.action({dataset:{vcAction:'preview',item:id,stage:'vc-inspection-scene'}});assert.equal(app.artCalls.at(-1).id,id);}
 assert.equal(app.calls.filter(call=>call.body).length,0);assert.equal(app.seam.summary().owned.length,0);
});
test('opening one earned badge shows its exact award and returns directly to the unchanged profile draft',async()=>{
 let returned=0;const app=fixture();await app.extension.onAccount();app.replies.set('/api/cosmetics/badges',{definitions:[{id:'profile-authored',name:'Profile Authored',description:'Unselected profile meaning',requirement:'Complete profile rule.'},{id:'reviewed-contribution',name:'Community Contribution',description:'Reviewed work selected',requirement:'A verified owner review.'}],awards:[{badge_id:'reviewed-contribution',valid:true,issued_at:1700000000000,issuer:'Reviewed by Owner'}]});
 const result=await app.cosmetics.openBadge('reviewed-contribution',{profileId:'account-a',returnTo:()=>{returned++;}});assert.equal(result,true);const html=app.nodes.get('dialog').innerHTML;assert.match(html,/Community Contribution/);assert.match(html,/Reviewed work selected/);assert.match(html,/A verified owner review/);assert.match(html,/Reviewed by Owner/);assert.match(html,/Earned and valid/);assert.doesNotMatch(html,/Unselected profile meaning/);assert.match(html,/Back to profile/);await app.seam.action({dataset:{vcAction:'return',item:'reviewed-contribution'}});assert.equal(returned,1);assert.equal(app.calls.filter(row=>row.body).length,0);
});
test('another profile badge inspection never borrows the viewer own award and respects private details',async()=>{
 const app=fixture();await app.extension.onAccount();app.replies.set('/api/cosmetics/badges',{definitions:[{id:'profile-authored',name:'Profile Authored',description:'Known meaning',requirement:'Complete profile rule.'}],awards:[{badge_id:'profile-authored',valid:true,issued_at:1700000000000,issuer:'VIEWER_ONLY_ISSUER'}]});app.replies.set('/api/profiles/account-b',{profile:{id:'account-b',detailsVisible:false,earnedBadges:[]}});await app.cosmetics.openBadge('profile-authored',{profileId:'account-b'});const html=app.nodes.get('dialog').innerHTML;assert.match(html,/Award details are private/);assert.doesNotMatch(html,/VIEWER_ONLY_ISSUER|Earned and valid/);assert.equal(app.calls.filter(row=>row.body).length,0);
});
test('a late badge detail request cannot replace a newer editor or survive account locking',async()=>{
 for(const mode of ['dialog','account']){const app=fixture(),slow=held();await app.extension.onAccount();app.replies.set('/api/cosmetics/badges',slow.promise);const opening=app.cosmetics.openBadge('profile-authored',{returnTo:()=>{throw Error('stale return');}});if(mode==='dialog')app.bridge.showDialog('New profile editor','Unsaved text','<p id="new-profile-draft">Keep it</p>');else{app.extension.onLock();app.state.account={id:'account-b'};}slow.resolve({definitions:[{id:'profile-authored',name:'Profile Authored',description:'Late',requirement:'Late'}],awards:[]});assert.equal(await opening,false);if(mode==='dialog')assert.match(app.nodes.get('dialog').innerHTML,/New profile editor/);assert.equal(app.calls.filter(row=>row.body).length,0);}
});
test('own instance inspection uses fresh exact provenance while other profile inspection uses only its visible showcase',async()=>{
 const app=fixture();await app.extension.onAccount();const id='gift:exact-instance';app.replies.set('/api/cosmetics/instances/'+encodeURIComponent(id),{instance:{id,catalog_id:'gift-rose',origin_kind:'gift',sender_username:'original_giver'}});assert.equal(await app.cosmetics.openItem('gift-rose',{instanceId:id,returnTo:()=>{},returnLabel:'Back to private collection'}),true);let html=app.nodes.get('dialog').innerHTML;assert.match(html,/Owned instance/);assert.match(html,/gift:exact-instance/);assert.match(html,/@original_giver/);assert.match(html,/Back to private collection/);app.replies.set('/api/profiles/account-b',{profile:{id:'account-b',username:'other_person',collectionVisible:true,showcase:[{instance_id:'public-instance',catalog_id:'gift-rose',origin_kind:'gift',show_sender:0}]}});assert.equal(await app.cosmetics.openItem('gift-rose',{instanceId:'public-instance',profileId:'account-b'}),true);html=app.nodes.get('dialog').innerHTML;assert.match(html,/Displayed instance/);assert.match(html,/@other_person/);assert.doesNotMatch(html,/@original_giver/);assert.ok(!app.calls.some(row=>row.route==='/api/cosmetics/instances/public-instance'));assert.equal(app.calls.filter(row=>row.body).length,0);
});
test('a hidden or transferred instance cannot produce a false inspection or replace the open profile draft',async()=>{
 const app=fixture();await app.extension.onAccount();app.bridge.showDialog('Profile draft','Unsaved','<p id="preserved-draft">Keep this</p>');app.replies.set('/api/profiles/account-b',{profile:{id:'account-b',collectionVisible:false,showcase:[]}});assert.equal(await app.cosmetics.openItem('gift-rose',{instanceId:'hidden-instance',profileId:'account-b'}),false);assert.match(app.nodes.get('dialog').innerHTML,/Profile draft/);assert.match(app.announcements.at(-1),/unavailable|visible/);app.replies.set('/api/cosmetics/instances/old-owned',()=>Promise.reject(Error('Ownership changed')));assert.equal(await app.cosmetics.openItem('gift-rose',{instanceId:'old-owned'}),false);assert.match(app.nodes.get('dialog').innerHTML,/Profile draft/);assert.equal(app.calls.filter(row=>row.body).length,0);
});
test('profile showcase and named grouping actions have separate destinations and never submit ownership writes',async()=>{
 const edits=[],groups=[],app=fixture({profilePanel:{edit:options=>edits.push(options)},giftCollections:{open:()=>groups.push('all'),openInstance:id=>groups.push(id)}});await app.extension.onAccount();await app.seam.action({dataset:{vcAction:'showcase',instance:'owned-instance'}});await app.seam.action({dataset:{vcAction:'organize-gifts'}});await app.seam.action({dataset:{vcAction:'group-instance',instance:'owned-instance'}});assert.equal(edits.length,1);assert.equal(edits[0].section,'showcase');assert.equal(edits[0].instanceId,'owned-instance');assert.deepEqual(groups,['all','owned-instance']);assert.equal(app.calls.filter(row=>row.body).length,0);await app.seam.collection('collected');assert.match(app.nodes.get('dialog').innerHTML,/Organize gifts/);
});

let failed=0;for(const[name,fn]of tests){try{await fn();console.log('PASS '+name);}catch(error){failed++;console.error('FAIL '+name,error);}}console.log(`${tests.length-failed}/${tests.length} cosmetics client checks passed. VM lifecycle and transport; no browser rasterization or real gifts claimed.`);process.exitCode=failed?1:0;})();
