LIBHEIF-JS 1.23.5 SOURCE AND BUILD RECORD

This archive contains the upstream source trees and build scripts associated
with the libheif-js1.23.5 HEIC decoder copied into VOIDLINE. Upstream source
files and license texts are unmodified. Additional notes, hashes and the
rebuild helper live outside those source trees.

SOURCE LAYOUT

libheif-js/ is catdad-experiments/libheif-js at commit
 d8ec4bc3bc5bf8055975577bccbbc7e1d7313c2d.
The npm1.23.5 metadata gitHead matches that commit. Its scripts/install.js
fetches the builder's v1.23.5 release, transforms the generated JS to es2019
with esbuild, and builds convenience bundles. Its package.json records the
upstream development dependencies; upstream did not pin every tool to an
exact patch version.

libheif-emscripten/ is catdad-experiments/libheif-emscripten at commit
 5c8968a44e9c68ae677e24790d77d001ed7fe7cc (v1.23.5).
The full source for its libheif submodule is overlaid in
libheif-emscripten/libheif/ at commit
 413e2a87e6a70b3eccc3a3adc5801179dd2d9e00.
That upstream CMake project declares libheif1.23.5. The builder's Git tree
submodule entry was checked against this commit. All source, headers, post.js,
CMake files, CI scripts and upstream license files are included.

libde265-1.0.15/ contains the complete extracted official1.0.15 release source.
The unmodified release archive is also retained at
 dependency-archives/libde265-1.0.15.tar.gz
because the upstream build-emscripten.sh consumes that file directly. Its
SHA256 is00251986c29d34d3af7117ed05874950c875dd9292d016be29d3b3762666511d.

The upstream WASM build downloads and links libde265 by default. Its AOM,
OpenJPEG, browser WebCodecs and uncompressed-codec switches are off. In the
included CMake sources, header compression is off by default, so its optional
zlib/Brotli path is not requested. JPEG is off by default and internal
libsharpyuv is off. No additional third-party decoder library is downloaded
by the selected build path. The installed WASM reports libheif1.23.5 and
libde2651.0.15; its format query reports HEVC decoding available and formats
2 through10 unavailable. Internal libheif formats remain part of libheif's
included source. This is not a complete binary bill-of-materials audit.

LICENSES

Original notices remain in every source tree. LICENSES/ additionally copies
unmodified top-level libheif-js/LICENSE, libheif/COPYING, libde265/COPYING and
the npm libheif-wasm/LICENSE. The latter matches the upstream release license
byte-for-byte. Read those upstream files for the applicable terms.

BUILD TOOLCHAIN AND REBUILD

The included .github/workflows/emscripten.yml selects Ubuntu22.04,
Emscripten3.1.61, Node24 and TypeScript5. It edits the libheif CI invocation
to set USE_WASM=1, USE_UNSAFE_EVAL=0 and USE_TYPESCRIPT=1. The exact workflow
and all called source scripts are retained. For a normal local rebuild:

1. Install the Emscripten SDK3.1.61 and activate its environment. The SDK is a
   separately obtained toolchain; it is not duplicated in this archive.
   https://emscripten.org/docs/getting_started/downloads.html
   https://github.com/emscripten-core/emsdk/tree/3.1.61
2. Use Node24 and install TypeScript5, plus CMake, make and the normal compiler
   build prerequisites documented in the included upstream sources.
3. From this archive root, run bash rebuild-wasm.sh. It places the exact
   libde265 source archive where the upstream build expects it and invokes
   the unmodified build-emscripten.sh with the selected flags.
4. The output is libheif-emscripten/libheif/libheif.js and libheif.wasm.
   For upstream distribution layout and JS transformations, use the included
   libheif-emscripten/dist-prep.sh and libheif-js/scripts/install.js. See the
   preserved upstream workflow for its release packaging and tests.

VOIDLINE's scripts/build-profile-images.mjs copies unmodified npm
libheif-wasm/libheif.js, libheif.wasm and LICENSE to dist/pkg/profile-images/.
They are standalone, same-origin assets loaded by the profile codec worker.
To experiment with a modified library, replace those standalone package
artifacts with rebuilt outputs and rebuild the application. The application
worker and full project build sources are separately available at:
 https://github.com/bndwhite11-spec/voidline-afterhours
No full toolchain rebuild was performed while preparing this archive, and
byte-for-byte reproducible rebuilds are not claimed. The upstream workflow's
rolling host packages and major-only Node/TypeScript selections may affect
newly generated outputs. This archive records the source/build provenance
that was checked, rather than inventing a binary reproducibility result.

INTEGRITY

PROVENANCE.json records URLs, exact commits, source-download SHA256 hashes,
npm metadata and deployed-library artifact hashes. SOURCE-FILES.sha256
covers all regular files in this archive except that checksum list itself.
The outer archive's SHA256 is published in the repository's third_party/
README.txt. The installed WASM matches the builder's v1.23.5 release bytes:
 184d3d20f8323877f13e9f5254f9c6a0ce272c9a3a2f823b0b2bcd2ee9f73f80
